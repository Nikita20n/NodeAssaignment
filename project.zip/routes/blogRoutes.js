const express = require("express");
const router = express.Router();
const Post = require("../models/post");

// Get all blog posts
router.get("/", async (req, res) => {
    try {
        const posts = await Post.find();
        console.log(posts)
        res.render("blog", { blogPosts: posts });
    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error");
    }
});

// Get single blog post
router.get("/:id", async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post) return res.status(404).send("Post not found");
        res.render("post", { post });
    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error");
    }
});

// Add a new blog post
router.post("/add", async (req, res) => {
    try {
        const { title, content } = req.body;
        console.log(`Title: ${title}`)
        console.log(`COntent ; ${content}`)
        const newPost = new Post({ title, content });
        await newPost.save();
        res.redirect("/blog");
    } catch (err) {
        console.error(err);
        res.status(500).send("Error adding post");
    }
});

module.exports = router;
