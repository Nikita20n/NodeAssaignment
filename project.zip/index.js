require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const exphbs = require("express-handlebars");
const path = require("path");

const app = express();

// MongoDB Connection
mongoose
    .connect("mongodb://admin:adminpass@localhost:27017/blogDB?authSource=admin", { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("MongoDB Connection Error:", err));

// Set Handlebars as the view engine
app.engine(
    "hbs",
    exphbs.engine({
      extname: "hbs",
      defaultLayout: "main",
      runtimeOptions: {
        allowProtoPropertiesByDefault: true, // ✅ Allow accessing prototype properties
        allowProtoMethodsByDefault: true,
      },
    })
  );
  
app.set("view engine", "hbs");

// Set static folder
app.use(express.static(path.join(__dirname, "public")));

// Middleware to parse request body
app.use(express.urlencoded({ extended: true }));

// ✅ Define Routes for Static Pages
app.get("/", (req, res) => {
    res.render("home");
});

app.get("/about", (req, res) => {
    res.render("about");
});

app.get("/contact", (req, res) => {
    res.render("contact");
});

// Blog Routes
const blogRoutes = require("./routes/blogRoutes");
app.use("/blog", blogRoutes);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
